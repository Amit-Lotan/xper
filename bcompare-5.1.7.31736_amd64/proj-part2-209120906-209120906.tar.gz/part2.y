%{
/* Bison parser for C--:
 *
 * 1. Defines the Grammar rules (BNF) for the language.
 * 2. Defines Operator Precedence and Associativity.
 * 3. Builds the Parse Tree bottom-up using mkNodeN().
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "part2.h" /* defines YYSTYPE as ParserNode* */

extern int yylex(void);
extern int yylineno;
extern char* yytext;

/* Global root of parse tree. part2_helpers.c expects this symbol to be set. */
ParserNode* parseTree = NULL;

/* Forward declaration for error reporting */
void yyerror(const char* msg);

/* mkNodeN
 * Purpose: Helper function to create a parent node with N children.
 * It handles linking the children together via the sibling pointer
 * before attaching the list to the new parent.
 *
 * Arguments:
 * type - The string tag for the node (e.g., "PROGRAM", "STMT")
 * n    - The number of children to pop from the stack/arguments
 * ...  - Variadic arguments (ParserNode pointers)
 */
static ParserNode* mkNodeN(const char* type, int n, ...)
{
    va_list ap;
    va_start(ap, n);

    ParserNode* first = NULL;
    ParserNode* tail  = NULL;

    for (int i = 0; i < n; ++i) {
        ParserNode* child = va_arg(ap, ParserNode*);
        if (child == NULL) {
            continue;
        }
        if (first == NULL) {
            first = child;
            tail  = child;
        } else {
            tail->sibling = child;
            tail = child;
        }
        /* If the child already has siblings (is a list), advance tail to the end */
        while (tail && tail->sibling) {
            tail = tail->sibling;
        }
    }

    va_end(ap);
    return makeNode(type, NULL, first);
}

%}

/* Token declarations (must match the tokens returned by lexer) */
%token TK_INT TK_FLOAT TK_VOID
%token TK_WRITE TK_READ
%token TK_WHILE TK_DO
%token TK_IF TK_THEN TK_ELSE
%token TK_RETURN

%token TK_ID
%token TK_INTEGERNUM TK_REALNUM
%token TK_STR

%token TK_RELOP TK_ADDOP TK_MULOP
%token TK_ASSIGN
%token TK_AND TK_OR TK_NOT

/* * Operator precedence / associativity
 * Defined from Lowest priority to Highest priority.
 * Used to resolve shift/reduce conflicts 
 */
%left TK_OR           /* Lowest */
%left TK_AND
%left TK_RELOP
%left TK_ADDOP
%left TK_MULOP
%right TK_NOT
%right TK_CAST        /* Highest: Token for Explicit Casting precedence */

/* * Dangling-else resolution: 
 * Ensures 'ELSE' binds to the nearest 'IF'.
 */
%nonassoc IF_NO_ELSE
%nonassoc TK_ELSE

%%

/* --- Grammar Rules --- */

/* Top-level Program Rule */
PROGRAM
    : FDEFS
        {
            $$ = mkNodeN("PROGRAM", 1, $1);
            parseTree = $$; /* Save result to global variable */
        }
    ;

/* Function Definitions List (Recursive) */
FDEFS
    : FDEFS FUNC_DEF_API BLK
        { $$ = mkNodeN("FDEFS", 3, $1, $2, $3); }
    | FDEFS FUNC_DEC_API
        { $$ = mkNodeN("FDEFS", 2, $1, $2); }
    | /* empty production (EPSILON) */
        { 
            /* Create an explicit EPSILON node for the tree */
            ParserNode* eps = makeNode("EPSILON", NULL, NULL);
            $$ = mkNodeN("FDEFS", 1, eps); 
        }
    ;

/* Function Declarations (Prototypes) */
FUNC_DEC_API
    : TYPE TK_ID '(' ')' ';'
        { $$ = mkNodeN("FUNC_DEC_API", 5, $1, $2, $3, $4, $5); }
    | TYPE TK_ID '(' FUNC_ARGLIST ')' ';'
        { $$ = mkNodeN("FUNC_DEC_API", 6, $1, $2, $3, $4, $5, $6); }
    ;

/* Function Implementations (Header part) */
FUNC_DEF_API
    : TYPE TK_ID '(' ')'
        { $$ = mkNodeN("FUNC_DEF_API", 4, $1, $2, $3, $4); }
    | TYPE TK_ID '(' FUNC_ARGLIST ')'
        { $$ = mkNodeN("FUNC_DEF_API", 5, $1, $2, $3, $4, $5); }
    ;

/* Function Argument Lists */
FUNC_ARGLIST
    : FUNC_ARGLIST ',' DCL
        { $$ = mkNodeN("FUNC_ARGLIST", 3, $1, $2, $3); }
    | DCL
        { $$ = mkNodeN("FUNC_ARGLIST", 1, $1); }
    ;

/* Code Block */
BLK
    : '{' STLIST '}'
        { $$ = mkNodeN("BLK", 3, $1, $2, $3); }
    ;

/* Declarations (Variables) */
DCL
    : TK_ID ':' TYPE
        { $$ = mkNodeN("DCL", 3, $1, $2, $3); }
    | TK_ID ',' DCL
        { $$ = mkNodeN("DCL", 3, $1, $2, $3); }
    ;

/* Types */
TYPE
    : TK_INT
        { $$ = mkNodeN("TYPE", 1, $1); }
    | TK_FLOAT
        { $$ = mkNodeN("TYPE", 1, $1); }
    | TK_VOID
        { $$ = mkNodeN("TYPE", 1, $1); }
    ;

/* Statement List (Recursive) */
STLIST
    : STLIST STMT
        { $$ = mkNodeN("STLIST", 2, $1, $2); }
    | /* empty production */
        { 
            ParserNode* eps = makeNode("EPSILON", NULL, NULL);
            $$ = mkNodeN("STLIST", 1, eps); 
        }
    ;

/* Statements */
STMT
    : DCL ';'
        { $$ = mkNodeN("STMT", 2, $1, $2); }
    | ASSN
        { $$ = mkNodeN("STMT", 1, $1); }
    | EXP ';'
        { $$ = mkNodeN("STMT", 2, $1, $2); }
    | CNTRL
        { $$ = mkNodeN("STMT", 1, $1); }
    | READ
        { $$ = mkNodeN("STMT", 1, $1); }
    | WRITE
        { $$ = mkNodeN("STMT", 1, $1); }
    | RETURN
        { $$ = mkNodeN("STMT", 1, $1); }
    | BLK
        { $$ = mkNodeN("STMT", 1, $1); }
    ;

/* Return Statement */
RETURN
    : TK_RETURN EXP ';'
        { $$ = mkNodeN("RETURN", 3, $1, $2, $3); }
    | TK_RETURN ';'
        { $$ = mkNodeN("RETURN", 2, $1, $2); }
    ;

/* IO Statements */
WRITE
    : TK_WRITE '(' EXP ')' ';'
        { $$ = mkNodeN("WRITE", 5, $1, $2, $3, $4, $5); }
    | TK_WRITE '(' TK_STR ')' ';'
        { $$ = mkNodeN("WRITE", 5, $1, $2, $3, $4, $5); }
    ;

READ
    : TK_READ '(' LVAL ')' ';'
        { $$ = mkNodeN("READ", 5, $1, $2, $3, $4, $5); }
    ;

/* Assignment Statement */
ASSN
    : LVAL TK_ASSIGN EXP ';'
        { $$ = mkNodeN("ASSN", 4, $1, $2, $3, $4); }
    ;

/* Left Value (Variable being assigned to) */
LVAL
    : TK_ID
        { $$ = mkNodeN("LVAL", 1, $1); }
    ;

/* Control Flow Statements */
CNTRL
    : TK_IF BEXP TK_THEN STMT TK_ELSE STMT
        { $$ = mkNodeN("CNTRL", 6, $1, $2, $3, $4, $5, $6); }
    | TK_IF BEXP TK_THEN STMT %prec IF_NO_ELSE
        { $$ = mkNodeN("CNTRL", 4, $1, $2, $3, $4); }
    | TK_WHILE BEXP TK_DO STMT
        { $$ = mkNodeN("CNTRL", 4, $1, $2, $3, $4); }
    ;

/* Boolean Expressions */
BEXP
    : BEXP TK_OR BEXP
        { $$ = mkNodeN("BEXP", 3, $1, $2, $3); }
    | BEXP TK_AND BEXP
        { $$ = mkNodeN("BEXP", 3, $1, $2, $3); }
    | TK_NOT BEXP
        { $$ = mkNodeN("BEXP", 2, $1, $2); }
    | EXP TK_RELOP EXP
        { $$ = mkNodeN("BEXP", 3, $1, $2, $3); }
    | '(' BEXP ')'
        { $$ = mkNodeN("BEXP", 3, $1, $2, $3); }
    ;

/* Arithmetic Expressions */
EXP
    : EXP TK_ADDOP EXP
        { $$ = mkNodeN("EXP", 3, $1, $2, $3); }
    | EXP TK_MULOP EXP
        { $$ = mkNodeN("EXP", 3, $1, $2, $3); }
    | '(' EXP ')'
        { $$ = mkNodeN("EXP", 3, $1, $2, $3); }
    /* * Explicit Casting: ( TYPE ) EXP
     * Uses %prec TK_CAST to ensure this rule has higher priority 
     * than ADDOP/MULOP, so (int)a+b parses as ((int)a)+b.
     */
    | '(' TYPE ')' EXP %prec TK_CAST 
        { $$ = mkNodeN("EXP", 4, $1, $2, $3, $4); }
    | TK_ID
        { $$ = mkNodeN("EXP", 1, $1); }
    | NUM
        { $$ = mkNodeN("EXP", 1, $1); }
    | CALL
        { $$ = mkNodeN("EXP", 1, $1); }
    ;

/* Numbers wrapper */
NUM
    : TK_INTEGERNUM
        { $$ = mkNodeN("NUM", 1, $1); }
    | TK_REALNUM
        { $$ = mkNodeN("NUM", 1, $1); }
    ;

/* Function Call */
CALL
    : TK_ID '(' CALL_ARGS ')'
        { $$ = mkNodeN("CALL", 4, $1, $2, $3, $4); }
    ;

/* Function Call Arguments */
CALL_ARGS
    : /* empty argument list */
        { 
            ParserNode* eps = makeNode("EPSILON", NULL, NULL);
            $$ = mkNodeN("CALL_ARGS", 1, eps); 
        }
    | POS_ARGLIST
        { $$ = mkNodeN("CALL_ARGS", 1, $1); }
    | NAMED_ARGLIST
        { $$ = mkNodeN("CALL_ARGS", 1, $1); }
    | POS_ARGLIST ',' NAMED_ARGLIST
        { $$ = mkNodeN("CALL_ARGS", 3, $1, $2, $3); }
    ;

/* Positional Arguments */
POS_ARGLIST
    : EXP
        { $$ = mkNodeN("POS_ARGLIST", 1, $1); }
    | POS_ARGLIST ',' EXP
        { $$ = mkNodeN("POS_ARGLIST", 3, $1, $2, $3); }
    ;

/* Named Arguments */
NAMED_ARGLIST
    : NAMED_ARG
        { $$ = mkNodeN("NAMED_ARGLIST", 1, $1); }
    | NAMED_ARGLIST ',' NAMED_ARG
        { $$ = mkNodeN("NAMED_ARGLIST", 3, $1, $2, $3); }
    ;

/* Individual Named Argument (e.g. param : value) */
NAMED_ARG
    : TK_ID ':' EXP
        { $$ = mkNodeN("NAMED_ARG", 3, $1, $2, $3); }
    ;

%%

/* Error handling function.
 * Prints the error message and the current line number in the right format
 */
void yyerror(const char* msg)
{
    (void)msg; /* msg is not used, we print in the required format */

    const char* lexeme = (yytext && yytext[0]) ? yytext : "EOF";
    printf("Syntax error: '%s' in line number %d\n", lexeme, yylineno);
    exit(2);
}